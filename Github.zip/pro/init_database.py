import mysql.connector

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'blogs4you'
}

def init_database():
    """Initialize database with admin user and categories"""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor()
        
        print("Initializing database...")
        
        # Check if admin user exists
        cursor.execute("SELECT id FROM users WHERE email = 'admin@blogs4you.com'")
        admin = cursor.fetchone()
        
        if not admin:
            print("Creating admin user...")
            cursor.execute("""
                INSERT INTO users (name, email, password, role, is_verified) 
                VALUES ('Admin', 'admin@blogs4you.com', 'Admin@123', 'admin', 1)
            """)
            conn.commit()
            print("✓ Admin user created (ID: 1)")
        else:
            print(f"✓ Admin user already exists (ID: {admin[0]})")
        
        # Check categories
        categories = ['Business', 'Education', 'Entertainment', 'Food', 'Health', 
                     'Lifestyle', 'Science', 'Sports', 'Technology', 'Travel']
        
        cursor.execute("SELECT COUNT(*) FROM categories")
        count = cursor.fetchone()[0]
        
        if count < 10:
            print(f"Creating {10 - count} categories...")
            for cat in categories:
                try:
                    cursor.execute("INSERT INTO categories (name) VALUES (%s)", (cat,))
                except:
                    pass  # Category might already exist
            conn.commit()
            print("✓ Categories created")
        else:
            print(f"✓ All {count} categories exist")
        
        # Verify setup
        cursor.execute("SELECT id, name, email, role FROM users WHERE role = 'admin' LIMIT 1")
        admin_user = cursor.fetchone()
        print(f"\nAdmin User: ID={admin_user[0]}, Name={admin_user[1]}, Email={admin_user[2]}, Role={admin_user[3]}")
        
        cursor.execute("SELECT COUNT(*) FROM categories")
        cat_count = cursor.fetchone()[0]
        print(f"Total Categories: {cat_count}")
        
        cursor.close()
        conn.close()
        
        print("\n✓ Database initialization complete!")
        return True
        
    except Exception as e:
        print(f"Error initializing database: {e}")
        return False

if __name__ == "__main__":
    init_database()
