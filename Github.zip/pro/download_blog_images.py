import mysql.connector
import requests
import os
import random
import time
from urllib.parse import quote_plus

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'blogs4you'
}

UPLOAD_DIR = 'static/uploads'

# Category-specific image keywords for better relevance
CATEGORY_IMAGES = {
    'Business': ['office', 'meeting', 'business', 'corporate', 'startup', 'finance', 'technology'],
    'Education': ['classroom', 'student', 'university', 'learning', 'books', 'study', 'school'],
    'Entertainment': ['movie', 'music', 'concert', 'gaming', 'theater', 'film', 'celebration'],
    'Food': ['food', 'cooking', 'restaurant', 'meal', 'kitchen', 'dining', 'cuisine'],
    'Health': ['health', 'fitness', 'medical', 'wellness', 'exercise', 'healthy', 'doctor'],
    'Lifestyle': ['lifestyle', 'fashion', 'home', 'travel', 'hobby', 'minimalist', 'decor'],
    'Science': ['science', 'laboratory', 'research', 'space', 'nature', 'technology', 'innovation'],
    'Sports': ['sports', 'athlete', 'fitness', 'stadium', 'competition', 'exercise', 'game'],
    'Technology': ['technology', 'computer', 'coding', 'digital', 'innovation', 'tech', 'software'],
    'Travel': ['travel', 'adventure', 'landscape', 'nature', 'destination', 'tourism', 'explore']
}

def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

def download_image_from_lorem_picsum(keywords, filename, width=800, height=600):
    """Download image from Lorem Picsum (reliable placeholder service)"""
    try:
        # Use Lorem Picsum with random seed for variety
        seed = random.randint(1, 10000)
        url = f"https://picsum.photos/seed/{seed}/{width}/{height}"
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        response = requests.get(url, headers=headers, timeout=15, allow_redirects=True)
        
        if response.status_code == 200 and len(response.content) > 1000:
            filepath = os.path.join(UPLOAD_DIR, filename)
            with open(filepath, 'wb') as f:
                f.write(response.content)
            print(f"    ✓ Downloaded: {filename}")
            return f"uploads/{filename}"
        else:
            print(f"    ✗ Failed to download: {filename}")
            return None
            
    except Exception as e:
        print(f"    ✗ Error downloading {filename}: {e}")
        return None

def get_existing_image_for_category(category):
    """Get an existing image for the category"""
    category_slug = category.lower().replace(' ', '_')
    # Try to find existing images for this category
    for i in range(1, 4):
        img_path = f"uploads/blog_{category_slug}_{i}.jpg"
        full_path = os.path.join('static', img_path)
        if os.path.exists(full_path):
            return img_path
    return None

def add_images_to_blogs():
    """Add images to blogs that don't have them"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    print("Adding images to blogs...")
    print("=" * 60)
    
    # Get all blogs
    cursor.execute("SELECT id, title, category FROM blogs ORDER BY id")
    blogs = cursor.fetchall()
    
    total_blogs = len(blogs)
    images_added = 0
    sections_added = 0
    
    for i, blog in enumerate(blogs, 1):
        blog_id = blog['id']
        category = blog['category']
        
        print(f"\n[{i}/{total_blogs}] Processing: {blog['title'][:50]}...")
        
        # Check if blog already has sections with images
        cursor.execute("SELECT COUNT(*) as count FROM blog_sections WHERE blog_id = %s AND section_type = 'image'", (blog_id,))
        existing_images = cursor.fetchone()['count']
        
        if existing_images > 0:
            print(f"    ℹ Already has {existing_images} images, skipping...")
            continue
        
        # Get keywords for this category
        keywords = CATEGORY_IMAGES.get(category, ['general', 'lifestyle'])
        
        # Download 3 images for this blog
        images_for_blog = []
        
        for img_num in range(1, 4):
            filename = f"blog_{category.lower().replace(' ', '_')}_{blog_id}_{img_num}.jpg"
            img_path = download_image_from_lorem_picsum(keywords, filename)
            
            if img_path:
                images_for_blog.append(img_path)
                images_added += 1
            
            time.sleep(0.3)  # Be respectful to the service
        
        # If no images downloaded, use existing ones
        if not images_for_blog:
            for img_num in range(1, 4):
                existing = get_existing_image_for_category(category)
                if existing:
                    images_for_blog.append(existing)
        
        # Add image sections to the blog
        if images_for_blog:
            # Get current max sort_order
            cursor.execute("SELECT MAX(sort_order) as max_order FROM blog_sections WHERE blog_id = %s", (blog_id,))
            result = cursor.fetchone()
            current_max = result['max_order'] if result['max_order'] else -1
            
            # Insert images at intervals (after every text section)
            for idx, img_path in enumerate(images_for_blog):
                sort_order = current_max + 1 + (idx * 2)  # Space them out
                cursor.execute("""
                    INSERT INTO blog_sections (blog_id, section_type, image_path, sort_order)
                    VALUES (%s, %s, %s, %s)
                """, (blog_id, 'image', img_path, sort_order))
                sections_added += 1
            
            conn.commit()
            print(f"    ✓ Added {len(images_for_blog)} images to blog {blog_id}")
        else:
            print(f"    ✗ Could not add images to blog {blog_id}")
    
    cursor.close()
    conn.close()
    
    print("\n" + "=" * 60)
    print("IMAGE ADDITION COMPLETE!")
    print(f"Total blogs processed: {total_blogs}")
    print(f"Images downloaded: {images_added}")
    print(f"Image sections added: {sections_added}")
    print("=" * 60)

if __name__ == "__main__":
    add_images_to_blogs()
