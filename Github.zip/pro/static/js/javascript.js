function toggleMenu() {
    const nav = document.getElementById('navMenu');
    if (nav) {
        nav.classList.toggle('active');
    }
}


/* Optional: Active link highlight */
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        document.querySelectorAll('.nav-link')
            .forEach(l => l.classList.remove('active'));
        link.classList.add('active');
    });
});


/* Registration form validation */
document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.querySelector('form[action="/register"]');
    if (registerForm) {
        registerForm.addEventListener('submit', function(event) {
            const nameEl = document.getElementById('name');
            const emailEl = document.getElementById('email');
            const passwordEl = document.getElementById('password');
            const confirmPasswordEl = document.getElementById('confirm_password');
            const phoneNumberEl = document.getElementById('phone_number');
            const genderEl = document.getElementById('gender');
            
            if (!nameEl || !emailEl || !passwordEl || !confirmPasswordEl) {
                return;
            }
            
            const name = nameEl.value.trim();
            const email = emailEl.value.trim();
            const password = passwordEl.value;
            const confirmPassword = confirmPasswordEl.value;
            const phoneNumber = phoneNumberEl ? phoneNumberEl.value.trim() : '';
            const gender = genderEl ? genderEl.value : '';

            let errors = [];

            // Name validation
            if (!name) {
                errors.push('Name is required.');
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!email) {
                errors.push('Email is required.');
            } else if (!emailRegex.test(email)) {
                errors.push('Please enter a valid email address.');
            }

            // Password validation
            if (!password) {
                errors.push('Password is required.');
            } else if (password.length < 8) {
                errors.push('Password must be at least 8 characters long.');
            } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(password)) {
                errors.push('Password must contain at least one lowercase letter, one uppercase letter, and one number.');
            }

            // Confirm password validation
            if (password !== confirmPassword) {
                errors.push('Passwords do not match.');
            }

            // Phone number validation (optional but if provided, check format)
            if (phoneNumber && !/^\+?[\d\s\-\(\)]+$/.test(phoneNumber)) {
                errors.push('Please enter a valid phone number.');
            }

            // Gender validation
            if (!gender) {
                errors.push('Please select your gender.');
            }

            if (errors.length > 0) {
                event.preventDefault();
                alert(errors.join('\n'));
            } else {
                // Show loading state
                const submitBtn = registerForm.querySelector('.btn.primary');
                if (submitBtn) {
                    submitBtn.classList.add('loading');
                    submitBtn.textContent = 'Registering...';
                }
            }
        });
    }


    // Login form loading
    const loginForm = document.querySelector('form[action="/login"]');
    if (loginForm) {
        loginForm.addEventListener('submit', function() {
            const submitBtn = loginForm.querySelector('.btn.primary');
            if (submitBtn) {
                submitBtn.classList.add('loading');
                submitBtn.textContent = 'Logging in...';
            }
        });
    }


    // Scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
            }
        });
    }, observerOptions);

    // Add animation classes to elements
    document.querySelectorAll('.feature-card').forEach((card, index) => {
        if (index % 2 === 0) {
            card.classList.add('fade-in');
        } else {
            card.classList.add('slide-in-left');
        }
        observer.observe(card);
    });

    document.querySelectorAll('.footer-section').forEach(section => {
        section.classList.add('fade-in');
        observer.observe(section);
    });

    // Particle effect - only on pages with hero section
    if (document.querySelector('.hero')) {
        createParticles();
    }

    // Parallax effect for hero
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const hero = document.querySelector('.hero');
        if (hero) {
            hero.style.backgroundPositionY = -(scrolled * 0.5) + 'px';
        }
    });

    // Dynamic text glow on hover
    const heroTitle = document.querySelector('.hero h1 span');
    if (heroTitle) {
        heroTitle.addEventListener('mouseenter', function() {
            this.style.animation = 'glow 2s ease-in-out infinite';
        });
        heroTitle.addEventListener('mouseleave', function() {
            this.style.animation = 'none';
        });
    }

    // Interactive form icons (if added)
    document.querySelectorAll('.form-group input').forEach(input => {
        input.addEventListener('focus', function() {
            const icon = this.nextElementSibling;
            if (icon && icon.classList.contains('input-icon')) {
                icon.style.color = '#667eea';
                icon.style.transform = 'scale(1.1) translateY(-50%)';
            }
        });
        input.addEventListener('blur', function() {
            const icon = this.nextElementSibling;
            if (icon && icon.classList.contains('input-icon')) {
                icon.style.color = '#ccc';
                icon.style.transform = 'translateY(-50%)';
            }
        });
    });

});

function createParticles() {
    const particlesContainer = document.createElement('div');
    particlesContainer.className = 'particles';
    document.body.appendChild(particlesContainer);

    for (let i = 0; i < 50; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = Math.random() * 100 + '%';
        particle.style.width = Math.random() * 6 + 2 + 'px';
        particle.style.height = particle.style.width;
        particle.style.animationDelay = Math.random() * 6 + 's';
        particlesContainer.appendChild(particle);
    }
}

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Mobile menu toggle
const hamburger = document.querySelector('.hamburger');
const nav = document.querySelector('.nav');

if (hamburger && nav) {
    hamburger.addEventListener('click', function() {
        nav.classList.toggle('active');
        this.classList.toggle('active');
    });
}

// Admin mobile menu toggle
const adminHamburger = document.getElementById('adminHamburger');
const adminNav = document.getElementById('adminNavMenu');

if (adminHamburger && adminNav) {
    adminHamburger.addEventListener('click', function() {
        adminNav.classList.toggle('active');
        this.classList.toggle('active');
    });
}

// Add loading state to all buttons on click (except those in forms which handle their own loading)
document.querySelectorAll('.btn:not([type="submit"])').forEach(btn => {
    btn.addEventListener('click', function(e) {
        // Skip if button is part of a form submission
        if (this.closest('form')) {
            return;
        }
        if (!this.classList.contains('loading')) {
            this.classList.add('loading');
            this.style.pointerEvents = 'none';
            const originalText = this.textContent;
            this.innerHTML = '<span class="spinner"></span> Loading...';
            const btn = this;
            setTimeout(() => {
                btn.classList.remove('loading');
                btn.style.pointerEvents = 'auto';
                btn.textContent = originalText;
            }, 2000); // Remove after 2 seconds for demo

        }
    });
});
