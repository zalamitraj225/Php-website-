from flask import Flask, render_template, session, redirect, url_for, request, g
import mysql.connector
import os
from datetime import datetime
from werkzeug.utils import secure_filename


app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Change this to a random secret key

def get_db():
    if 'db' not in g:
        g.db = mysql.connector.connect(host='localhost', user='root', password='root', database='blogs4you')
    return g.db

def get_cursor():
    return get_db().cursor(dictionary=True)

def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()
    schema_path = os.path.join(os.path.dirname(__file__), 'schema.sql')
    with open(schema_path, 'r') as f:
        sql = f.read()
    cursor = db.cursor()
    # Split SQL into individual statements
    statements = sql.split(';')
    for statement in statements:
        statement = statement.strip()
        if statement:
            try:
                cursor.execute(statement)
            except mysql.connector.Error as err:
                print(f"Error executing statement: {err}")
                print(f"Statement: {statement}")
                # Continue with other statements
    db.commit()

@app.before_request
def before_request():
    g.db = get_db()

@app.teardown_request
def teardown_request(exception):
    close_db()

@app.route('/')
def home():
    current_year = datetime.now().year
    cursor = get_cursor()
    cursor.execute('SELECT b.id, b.title, b.content, u.name, b.category, b.created_at, b.image FROM blogs b JOIN users u ON b.uploaded_by = u.id WHERE b.is_published = 1 ORDER BY b.created_at DESC LIMIT 6')
    latest_blogs = cursor.fetchall()
    
    # Get approved testimonials for home page
    cursor.execute('''
        SELECT t.*, u.name as user_name 
        FROM testimonials t
        JOIN users u ON t.user_id = u.id
        WHERE t.is_approved = 1
        ORDER BY t.created_at DESC
    ''')
    testimonials = cursor.fetchall()
    
    return render_template('index.html', current_year=current_year, latest_blogs=latest_blogs, testimonials=testimonials)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        if not email or not password:
            return render_template('login.html', error='Email and password are required')
        cursor = get_cursor()
        cursor.execute('SELECT * FROM users WHERE email = %s AND password = %s', (email, password))
        user = cursor.fetchone()
        if user:
            session['user_id'] = user['id']
            session['name'] = user['name']
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error='Invalid credentials')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name'].strip()
        email = request.form['email'].strip()
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        phone_number = request.form.get('phone_number', '').strip()
        gender = request.form.get('gender')
        address = request.form.get('address', '').strip()
        country = request.form.get('country', '').strip()

        # Server-side validation
        import re
        errors = []

        if not name:
            errors.append('Name is required.')
        if not email:
            errors.append('Email is required.')
        elif not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$', email):
            errors.append('Please enter a valid email address.')
        if not password:
            errors.append('Password is required.')
        elif len(password) < 8:
            errors.append('Password must be at least 8 characters long.')
        elif not re.search(r'(?=.*[a-z])(?=.*[A-Z])(?=.*\d)', password):
            errors.append('Password must contain at least one lowercase letter, one uppercase letter, and one number.')
        if password != confirm_password:
            errors.append('Passwords do not match.')
        if phone_number and not re.match(r'^\+?[\d\s\-\(\)]+$', phone_number):
            errors.append('Please enter a valid phone number.')
        if not gender:
            errors.append('Please select your gender.')

        if errors:
            return render_template('register.html', error=' '.join(errors))

        cursor = get_cursor()
        try:
            cursor.execute('INSERT INTO users (name, email, password, phone_number, gender, address, country) VALUES (%s, %s, %s, %s, %s, %s, %s)', (name, email, password, phone_number, gender, address, country))
            get_db().commit()
            # Auto-login after successful registration
            cursor.execute('SELECT id, name FROM users WHERE email = %s', (email,))
            user = cursor.fetchone()
            if user:
                session['user_id'] = user['id']
                session['name'] = user['name']
            return redirect(url_for('home'))
        except mysql.connector.IntegrityError:
            return render_template('register.html', error='Email already exists')
        except Exception as e:
            return render_template('register.html', error='An error occurred during registration. Please try again.')
    return render_template('register.html')

@app.route('/blogs')
def blogs():
    cursor = get_cursor()
    cursor.execute('SELECT b.id, b.title, b.content, u.name, b.category, b.created_at, b.image, b.views FROM blogs b JOIN users u ON b.uploaded_by = u.id WHERE b.is_published = 1')
    blogs_list = cursor.fetchall()
    return render_template('blogs.html', blogs=blogs_list)


@app.route('/blog/<int:blog_id>')
def view_blog(blog_id):
    cursor = get_cursor()
    cursor.execute('SELECT b.*, u.name as author_name FROM blogs b JOIN users u ON b.uploaded_by = u.id WHERE b.id = %s AND b.is_published = 1', (blog_id,))
    blog = cursor.fetchone()
    
    if not blog:
        return redirect(url_for('blogs'))
    
    # Increment views counter
    cursor.execute('UPDATE blogs SET views = views + 1 WHERE id = %s', (blog_id,))
    get_db().commit()
    
    # Get blog sections
    cursor.execute('''
        SELECT * FROM blog_sections 
        WHERE blog_id = %s 
        ORDER BY sort_order ASC
    ''', (blog_id,))
    blog_sections = cursor.fetchall()
    
    # If no sections exist, create a default text section from blog content
    if not blog_sections:
        blog_sections = [{'section_type': 'text', 'content': blog['content'], 'image_path': None}]
    
    # Get comments with user info

    cursor.execute('''
        SELECT c.*, u.name as user_name 
        FROM comments c 
        JOIN users u ON c.user_id = u.id 
        WHERE c.blog_id = %s AND c.is_approved = 1 AND c.parent_id IS NULL
        ORDER BY c.created_at DESC
    ''', (blog_id,))
    comments = cursor.fetchall()
    
    # Get replies for each comment
    for comment in comments:
        cursor.execute('''
            SELECT c.*, u.name as user_name 
            FROM comments c 
            JOIN users u ON c.user_id = u.id 
            WHERE c.parent_id = %s AND c.is_approved = 1
            ORDER BY c.created_at ASC
        ''', (comment['id'],))
        comment['replies'] = cursor.fetchall()
    
    # Get likes count
    cursor.execute('SELECT COUNT(*) as count FROM blog_likes WHERE blog_id = %s', (blog_id,))
    likes_count = cursor.fetchone()['count']
    
    # Check if user liked the blog
    user_liked = False
    if 'user_id' in session:
        cursor.execute('SELECT id FROM blog_likes WHERE blog_id = %s AND user_id = %s', (blog_id, session['user_id']))
        user_liked = cursor.fetchone() is not None
    
    # Check if user bookmarked the blog
    user_bookmarked = False
    if 'user_id' in session:
        cursor.execute('SELECT id FROM bookmarks WHERE blog_id = %s AND user_id = %s', (blog_id, session['user_id']))
        user_bookmarked = cursor.fetchone() is not None
    
    # Get related blogs (same category)
    cursor.execute('''
        SELECT b.id, b.title, b.content, u.name, b.category, b.created_at, b.image 
        FROM blogs b 
        JOIN users u ON b.uploaded_by = u.id 
        WHERE b.category = %s AND b.id != %s AND b.is_published = 1
        ORDER BY b.created_at DESC LIMIT 3
    ''', (blog['category'], blog_id))
    related_blogs = cursor.fetchall()
    
    return render_template('view_blog.html', blog=blog, comments=comments, 
                          likes_count=likes_count, user_liked=user_liked,
                          user_bookmarked=user_bookmarked, related_blogs=related_blogs,
                          blog_sections=blog_sections)



@app.route('/blog/<int:blog_id>/comment', methods=['POST'])
def add_comment(blog_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    content = request.form.get('content', '').strip()
    parent_id = request.form.get('parent_id')
    
    if not content:
        return redirect(url_for('view_blog', blog_id=blog_id))
    
    cursor = get_cursor()
    cursor.execute('SELECT is_published FROM blogs WHERE id = %s', (blog_id,))
    blog = cursor.fetchone()
    
    if not blog or not blog['is_published']:
        return redirect(url_for('blogs'))
    
    if parent_id:
        cursor.execute('''
            INSERT INTO comments (blog_id, user_id, content, parent_id) 
            VALUES (%s, %s, %s, %s)
        ''', (blog_id, session['user_id'], content, parent_id))
    else:
        cursor.execute('''
            INSERT INTO comments (blog_id, user_id, content) 
            VALUES (%s, %s, %s)
        ''', (blog_id, session['user_id'], content))
    
    get_db().commit()
    return redirect(url_for('view_blog', blog_id=blog_id))


@app.route('/blog/<int:blog_id>/like', methods=['POST'])
def like_blog(blog_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cursor = get_cursor()
    
    # Check if already liked
    cursor.execute('SELECT id FROM blog_likes WHERE blog_id = %s AND user_id = %s', 
                   (blog_id, session['user_id']))
    existing = cursor.fetchone()
    
    if existing:
        # Unlike
        cursor.execute('DELETE FROM blog_likes WHERE id = %s', (existing['id'],))
    else:
        # Like
        cursor.execute('INSERT INTO blog_likes (blog_id, user_id) VALUES (%s, %s)',
                       (blog_id, session['user_id']))
    
    get_db().commit()
    return redirect(url_for('view_blog', blog_id=blog_id))


@app.route('/blog/<int:blog_id>/bookmark', methods=['POST'])
def bookmark_blog(blog_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cursor = get_cursor()
    
    # Check if already bookmarked
    cursor.execute('SELECT id FROM bookmarks WHERE blog_id = %s AND user_id = %s', 
                   (blog_id, session['user_id']))
    existing = cursor.fetchone()
    
    if existing:
        # Remove bookmark
        cursor.execute('DELETE FROM bookmarks WHERE id = %s', (existing['id'],))
    else:
        # Add bookmark
        cursor.execute('INSERT INTO bookmarks (blog_id, user_id) VALUES (%s, %s)',
                       (blog_id, session['user_id']))
    
    get_db().commit()
    return redirect(url_for('view_blog', blog_id=blog_id))


@app.route('/my-bookmarks')
def my_bookmarks():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cursor = get_cursor()
    cursor.execute('''
        SELECT b.id, b.title, b.content, u.name, b.category, b.created_at, b.image, b.views
        FROM bookmarks bm
        JOIN blogs b ON bm.blog_id = b.id
        JOIN users u ON b.uploaded_by = u.id
        WHERE bm.user_id = %s AND b.is_published = 1
        ORDER BY bm.created_at DESC
    ''', (session['user_id'],))
    bookmarks = cursor.fetchall()
    
    return render_template('my_bookmarks.html', bookmarks=bookmarks)


@app.route('/testimonials', methods=['GET', 'POST'])
def testimonials():
    cursor = get_cursor()
    
    if request.method == 'POST':
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        content = request.form.get('content', '').strip()
        rating = request.form.get('rating', 5)
        
        if not content:
            return render_template('testimonials.html', error='Content is required', testimonials=[])
        
        cursor.execute('''
            INSERT INTO testimonials (user_id, content, rating) 
            VALUES (%s, %s, %s)
        ''', (session['user_id'], content, rating))
        get_db().commit()
        
        return redirect(url_for('testimonials'))
    
    # Get approved testimonials
    cursor.execute('''
        SELECT t.*, u.name as user_name 
        FROM testimonials t
        JOIN users u ON t.user_id = u.id
        WHERE t.is_approved = 1
        ORDER BY t.created_at DESC
    ''')
    testimonials_list = cursor.fetchall()
    
    return render_template('testimonials.html', testimonials=testimonials_list)


# =====================================================
# USER BLOG CREATION ROUTES
# =====================================================

@app.route('/user/create-blog', methods=['GET', 'POST'])
def user_create_blog():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cursor = get_cursor()
    cursor.execute('SELECT * FROM categories')
    categories = cursor.fetchall()
    
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        category = request.form.get('category', '').strip()
        section_types = request.form.getlist('section_type[]')
        section_contents = request.form.getlist('section_content[]')
        section_images = request.files.getlist('section_image[]')
        main_image = request.files.get('main_image')
        
        if not title or not category:
            return render_template('user_create_blog.html', categories=categories, error='Title and category are required')
        
        # Build content from sections for backward compatibility
        content_parts = []
        for i, section_type in enumerate(section_types):
            if section_type == 'text' and i < len(section_contents):
                if section_contents[i].strip():
                    content_parts.append(section_contents[i].strip())
        
        content = '\n\n'.join(content_parts) if content_parts else 'No content'
        
        # Handle main image upload
        main_image_path = None
        if main_image and main_image.filename:
            filename = secure_filename(main_image.filename)
            upload_folder = os.path.join('static', 'uploads')
            os.makedirs(upload_folder, exist_ok=True)
            filepath = os.path.join(upload_folder, filename)
            main_image.save(filepath)
            main_image_path = f'uploads/{filename}'
        
        # Insert blog with is_approved = 0 (pending approval)
        cursor.execute(
            'INSERT INTO blogs (title, content, category, image, uploaded_by, is_published, is_approved, submitted_by, views) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)',
            (title, content, category, main_image_path, session['user_id'], 0, 0, session['user_id'], 0)
        )

        get_db().commit()
        blog_id = cursor.lastrowid
        
        # Process sections
        image_index = 0
        for i, section_type in enumerate(section_types):
            if section_type == 'text':
                if i < len(section_contents) and section_contents[i].strip():
                    cursor.execute(
                        'INSERT INTO blog_sections (blog_id, section_type, content, sort_order) VALUES (%s, %s, %s, %s)',
                        (blog_id, 'text', section_contents[i].strip(), i)
                    )
            elif section_type == 'image':
                # Handle image upload for this section
                if image_index < len(section_images):
                    image = section_images[image_index]
                    if image and image.filename:
                        filename = secure_filename(image.filename)
                        upload_folder = os.path.join('static', 'uploads')
                        os.makedirs(upload_folder, exist_ok=True)
                        filepath = os.path.join(upload_folder, filename)
                        image.save(filepath)
                        image_path = f'uploads/{filename}'
                        
                        # Set first section image as featured image if no main image
                        if main_image_path is None:
                            main_image_path = image_path
                            cursor.execute('UPDATE blogs SET image = %s WHERE id = %s', (image_path, blog_id))
                        
                        cursor.execute(
                            'INSERT INTO blog_sections (blog_id, section_type, image_path, sort_order) VALUES (%s, %s, %s, %s)',
                            (blog_id, 'image', image_path, i)
                        )
                    image_index += 1
        
        get_db().commit()
        return redirect(url_for('user_my_blogs'))
    
    return render_template('user_create_blog.html', categories=categories)





@app.route('/user/my-blogs')
def user_my_blogs():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cursor = get_cursor()
    
    # Get user's blogs
    cursor.execute('''
        SELECT b.*, u.name as author_name 
        FROM blogs b 
        JOIN users u ON b.uploaded_by = u.id 
        WHERE b.submitted_by = %s OR b.uploaded_by = %s
        ORDER BY b.created_at DESC
    ''', (session['user_id'], session['user_id']))
    blogs = cursor.fetchall()
    
    # Calculate stats
    stats = {
        'published': sum(1 for b in blogs if b['is_approved'] and b['is_published']),
        'pending': sum(1 for b in blogs if not b['is_approved']),
        'total': len(blogs)
    }
    
    return render_template('user_my_blogs.html', blogs=blogs, stats=stats)


@app.route('/user/blog/delete/<int:blog_id>', methods=['POST'])
def user_delete_blog(blog_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cursor = get_cursor()
    
    # Verify ownership
    cursor.execute('SELECT uploaded_by, submitted_by FROM blogs WHERE id = %s', (blog_id,))
    blog = cursor.fetchone()
    
    if not blog or (blog['uploaded_by'] != session['user_id'] and blog['submitted_by'] != session['user_id']):
        return redirect(url_for('user_my_blogs'))
    
    cursor.execute('DELETE FROM blogs WHERE id = %s', (blog_id,))
    get_db().commit()
    
    return redirect(url_for('user_my_blogs'))













# =====================================================
# COMMUNITY ROUTE
# =====================================================

@app.route('/community')
def community():
    cursor = get_cursor()
    
    # Get popular blogs (most liked)
    cursor.execute('''
        SELECT b.id, b.title, b.content, u.name, b.category, b.created_at, b.image, b.views,
               COUNT(bl.id) as likes_count
        FROM blogs b
        JOIN users u ON b.uploaded_by = u.id
        LEFT JOIN blog_likes bl ON b.id = bl.blog_id
        WHERE b.is_published = 1
        GROUP BY b.id
        ORDER BY likes_count DESC, b.views DESC
        LIMIT 6
    ''')
    popular_blogs = cursor.fetchall()
    
    # Get recent comments
    cursor.execute('''
        SELECT c.*, u.name as user_name, b.title as blog_title, b.id as blog_id
        FROM comments c
        JOIN users u ON c.user_id = u.id
        JOIN blogs b ON c.blog_id = b.id
        WHERE c.is_approved = 1
        ORDER BY c.created_at DESC
        LIMIT 5
    ''')
    recent_comments = cursor.fetchall()
    
    # Get top contributors (users with most blogs)
    cursor.execute('''
        SELECT u.id, u.name, COUNT(b.id) as blog_count
        FROM users u
        JOIN blogs b ON u.id = b.uploaded_by
        WHERE b.is_published = 1
        GROUP BY u.id
        ORDER BY blog_count DESC
        LIMIT 5
    ''')
    top_contributors = cursor.fetchall()
    
    return render_template('community.html', 
                          popular_blogs=popular_blogs,
                          recent_comments=recent_comments,
                          top_contributors=top_contributors)


@app.route('/categories')
def categories():
    cursor = get_cursor()
    cursor.execute('SELECT * FROM categories')
    categories_list = cursor.fetchall()
    return render_template('categories.html', categories=categories_list)


@app.route('/category/<int:category_id>')
@app.route('/categories/<int:category_id>')
def category_blogs(category_id):
    cursor = get_cursor()
    cursor.execute('SELECT * FROM categories WHERE id = %s', (category_id,))
    category = cursor.fetchone()
    if not category:
        return redirect(url_for('categories'))
    
    cursor.execute('''
        SELECT b.id, b.title, b.content, u.name, b.category, b.created_at, b.image, b.views
        FROM blogs b
        JOIN users u ON b.uploaded_by = u.id
        WHERE b.category = %s AND b.is_published = 1
        ORDER BY b.created_at DESC
    ''', (category['name'],))
    blogs_list = cursor.fetchall()
    
    # Get first section image for each blog to show unique images in cards
    for blog in blogs_list:
        cursor.execute('''
            SELECT image_path FROM blog_sections 
            WHERE blog_id = %s AND section_type = 'image' 
            ORDER BY sort_order ASC LIMIT 1
        ''', (blog['id'],))
        section = cursor.fetchone()
        if section and section['image_path']:
            blog['image'] = section['image_path']
    
    return render_template('category_blogs.html', category=category, blogs=blogs_list)




@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))


# =====================================================
# ADMIN ROUTES
# =====================================================

@app.route('/admin')
def admin_dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    # Get stats
    cursor.execute('SELECT COUNT(*) as count FROM blogs')
    total_blogs = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM users')
    total_users = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM categories')
    total_categories = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM blogs WHERE is_published = 0')
    pending_blogs = cursor.fetchone()['count']
    
    return render_template('admin_dashboard.html', 
                          total_blogs=total_blogs,
                          total_users=total_users,
                          total_categories=total_categories,
                          pending_blogs=pending_blogs)


@app.route('/admin/blogs')
def admin_blogs():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    cursor.execute('SELECT b.*, u.name as author_name FROM blogs b JOIN users u ON b.uploaded_by = u.id ORDER BY b.created_at DESC')
    blogs = cursor.fetchall()
    return render_template('admin_blogs.html', blogs=blogs)


@app.route('/admin/blogs/add', methods=['GET', 'POST'])
def admin_add_blog():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        category = request.form.get('category', '').strip()
        section_types = request.form.getlist('section_type[]')
        section_contents = request.form.getlist('section_content[]')
        section_images = request.files.getlist('section_image[]')
        main_image = request.files.get('main_image')
        
        if not title or not category:
            cursor.execute('SELECT * FROM categories')
            categories = cursor.fetchall()
            return render_template('admin_add_blog.html', categories=categories, error='Title and category are required')
        
        # Build content from sections for backward compatibility
        content_parts = []
        for i, section_type in enumerate(section_types):
            if section_type == 'text' and i < len(section_contents):
                if section_contents[i].strip():
                    content_parts.append(section_contents[i].strip())
        
        content = '\n\n'.join(content_parts) if content_parts else 'No content'
        
        # Handle main image upload
        main_image_path = None
        if main_image and main_image.filename:
            filename = secure_filename(main_image.filename)
            upload_folder = os.path.join('static', 'uploads')
            os.makedirs(upload_folder, exist_ok=True)
            filepath = os.path.join(upload_folder, filename)
            main_image.save(filepath)
            main_image_path = f'uploads/{filename}'
        
        # Insert blog with is_published = 1 (admin blogs are auto-published)
        cursor.execute(
            'INSERT INTO blogs (title, content, category, image, uploaded_by, is_published, is_approved, submitted_by, views) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)',
            (title, content, category, main_image_path, session['user_id'], 1, 1, session['user_id'], 0)
        )
        get_db().commit()
        blog_id = cursor.lastrowid
        
        # Process sections
        image_index = 0
        for i, section_type in enumerate(section_types):
            if section_type == 'text':
                if i < len(section_contents) and section_contents[i].strip():
                    cursor.execute(
                        'INSERT INTO blog_sections (blog_id, section_type, content, sort_order) VALUES (%s, %s, %s, %s)',
                        (blog_id, 'text', section_contents[i].strip(), i)
                    )
            elif section_type == 'image':
                # Handle image upload for this section
                if image_index < len(section_images):
                    image = section_images[image_index]
                    if image and image.filename:
                        filename = secure_filename(image.filename)
                        upload_folder = os.path.join('static', 'uploads')
                        os.makedirs(upload_folder, exist_ok=True)
                        filepath = os.path.join(upload_folder, filename)
                        image.save(filepath)
                        image_path = f'uploads/{filename}'
                        
                        cursor.execute(
                            'INSERT INTO blog_sections (blog_id, section_type, image_path, sort_order) VALUES (%s, %s, %s, %s)',
                            (blog_id, 'image', image_path, i)
                        )
                    image_index += 1
        
        get_db().commit()
        return redirect(url_for('admin_blogs'))
    
    cursor.execute('SELECT * FROM categories')
    categories = cursor.fetchall()
    return render_template('admin_add_blog.html', categories=categories)




@app.route('/admin/blogs/edit/<int:blog_id>', methods=['GET', 'POST'])
def admin_edit_blog(blog_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        category = request.form.get('category', '').strip()
        is_published = 1 if request.form.get('is_published') else 0
        section_types = request.form.getlist('section_type[]')
        section_contents = request.form.getlist('section_content[]')
        section_images = request.files.getlist('section_image[]')
        main_image = request.files.get('main_image')
        
        if not title or not category:
            cursor.execute('SELECT * FROM blogs WHERE id = %s', (blog_id,))
            blog = cursor.fetchone()
            cursor.execute('SELECT * FROM categories')
            categories = cursor.fetchall()
            cursor.execute('SELECT * FROM blog_sections WHERE blog_id = %s ORDER BY sort_order', (blog_id,))
            blog_sections = cursor.fetchall()
            return render_template('admin_edit_blog.html', blog=blog, categories=categories, blog_sections=blog_sections, error='Title and category are required')
        
        # Build content from sections for backward compatibility
        content_parts = []
        for i, section_type in enumerate(section_types):
            if section_type == 'text' and i < len(section_contents):
                if section_contents[i].strip():
                    content_parts.append(section_contents[i].strip())
        
        content = '\n\n'.join(content_parts) if content_parts else 'No content'
        
        # Handle main image upload
        if main_image and main_image.filename:
            filename = secure_filename(main_image.filename)
            upload_folder = os.path.join('static', 'uploads')
            os.makedirs(upload_folder, exist_ok=True)
            filepath = os.path.join(upload_folder, filename)
            main_image.save(filepath)
            main_image_path = f'uploads/{filename}'
            
            cursor.execute('UPDATE blogs SET title = %s, content = %s, category = %s, image = %s, is_published = %s WHERE id = %s',
                           (title, content, category, main_image_path, is_published, blog_id))
        else:
            cursor.execute('UPDATE blogs SET title = %s, content = %s, category = %s, is_published = %s WHERE id = %s',
                           (title, content, category, is_published, blog_id))
        
        # Delete old sections and re-insert new ones
        cursor.execute('DELETE FROM blog_sections WHERE blog_id = %s', (blog_id,))
        
        # Process new sections
        image_index = 0
        for i, section_type in enumerate(section_types):
            if section_type == 'text':
                if i < len(section_contents) and section_contents[i].strip():
                    cursor.execute(
                        'INSERT INTO blog_sections (blog_id, section_type, content, sort_order) VALUES (%s, %s, %s, %s)',
                        (blog_id, 'text', section_contents[i].strip(), i)
                    )
            elif section_type == 'image':
                # Handle image upload for this section
                if image_index < len(section_images):
                    image = section_images[image_index]
                    if image and image.filename:
                        filename = secure_filename(image.filename)
                        upload_folder = os.path.join('static', 'uploads')
                        os.makedirs(upload_folder, exist_ok=True)
                        filepath = os.path.join(upload_folder, filename)
                        image.save(filepath)
                        image_path = f'uploads/{filename}'
                        
                        cursor.execute(
                            'INSERT INTO blog_sections (blog_id, section_type, image_path, sort_order) VALUES (%s, %s, %s, %s)',
                            (blog_id, 'image', image_path, i)
                        )
                    image_index += 1
        
        get_db().commit()
        return redirect(url_for('admin_blogs'))
    
    cursor.execute('SELECT * FROM blogs WHERE id = %s', (blog_id,))
    blog = cursor.fetchone()
    
    cursor.execute('SELECT * FROM categories')
    categories = cursor.fetchall()
    
    cursor.execute('SELECT * FROM blog_sections WHERE blog_id = %s ORDER BY sort_order', (blog_id,))
    blog_sections = cursor.fetchall()
    
    return render_template('admin_edit_blog.html', blog=blog, categories=categories, blog_sections=blog_sections)



@app.route('/admin/blogs/delete/<int:blog_id>', methods=['POST'])
def admin_delete_blog(blog_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    cursor.execute('DELETE FROM blogs WHERE id = %s', (blog_id,))
    get_db().commit()
    return redirect(url_for('admin_blogs'))


@app.route('/admin/categories')
def admin_categories():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    cursor.execute('SELECT * FROM categories')
    categories = cursor.fetchall()
    return render_template('admin_categories.html', categories=categories)


@app.route('/admin/categories/add', methods=['GET', 'POST'])
def admin_add_category():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    if request.method == 'POST':
        name = request.form.get('name')
        
        cursor.execute('INSERT INTO categories (name) VALUES (%s)', (name,))
        get_db().commit()
        return redirect(url_for('admin_categories'))
    
    return render_template('admin_add_category.html')




@app.route('/admin/categories/edit/<int:category_id>', methods=['GET', 'POST'])
def admin_edit_category(category_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    if request.method == 'POST':
        name = request.form.get('name')
        
        cursor.execute('UPDATE categories SET name = %s WHERE id = %s',
                       (name, category_id))
        get_db().commit()
        return redirect(url_for('admin_categories'))
    
    cursor.execute('SELECT * FROM categories WHERE id = %s', (category_id,))
    category = cursor.fetchone()
    return render_template('admin_edit_category.html', category=category)



@app.route('/admin/categories/delete/<int:category_id>', methods=['POST'])
def admin_delete_category(category_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    cursor.execute('DELETE FROM categories WHERE id = %s', (category_id,))
    get_db().commit()
    return redirect(url_for('admin_categories'))


@app.route('/admin/users')
def admin_users():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    cursor.execute('SELECT * FROM users')
    users = cursor.fetchall()
    return render_template('admin_users.html', users=users)


@app.route('/admin/users/edit/<int:user_id>', methods=['GET', 'POST'])
def admin_edit_user(user_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        phone_number = request.form.get('phone_number', '').strip()
        gender = request.form.get('gender')
        address = request.form.get('address', '').strip()
        country = request.form.get('country', '').strip()
        is_verified = 1 if request.form.get('is_verified') else 0
        role = request.form.get('role')
        password = request.form.get('password', '').strip()

        # Validation
        if not name or not email or not role:
            return render_template('admin_edit_user.html',
                                 user={'id': user_id, 'name': name, 'email': email, 'phone_number': phone_number,
                                       'gender': gender, 'address': address, 'country': country,
                                       'is_verified': is_verified, 'role': role},
                                 error='Name, email, and role are required')

        # Update user data
        update_fields = []
        update_values = []

        update_fields.extend(['name = %s', 'email = %s', 'phone_number = %s', 'gender = %s',
                             'address = %s', 'country = %s', 'is_verified = %s', 'role = %s'])
        update_values.extend([name, email, phone_number, gender, address, country, is_verified, role])

        # Only update password if provided
        if password:
            update_fields.append('password = %s')
            update_values.append(password)

        update_values.append(user_id)

        cursor.execute(f'UPDATE users SET {", ".join(update_fields)} WHERE id = %s', update_values)
        get_db().commit()
        return redirect(url_for('admin_users'))

    cursor.execute('SELECT * FROM users WHERE id = %s', (user_id,))
    user = cursor.fetchone()
    return render_template('admin_edit_user.html', user=user)


@app.route('/admin/users/delete/<int:user_id>', methods=['POST'])
def admin_delete_user(user_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    cursor.execute('DELETE FROM users WHERE id = %s', (user_id,))
    get_db().commit()
    return redirect(url_for('admin_users'))



# =====================================================
# PROFILE ROUTES
# =====================================================

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cursor = get_cursor()
    
    # Get user info
    cursor.execute('SELECT * FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    
    # Get user stats
    cursor.execute('SELECT COUNT(*) as count FROM blogs WHERE uploaded_by = %s', (session['user_id'],))
    blogs_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM comments WHERE user_id = %s', (session['user_id'],))
    comments_count = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM blog_likes WHERE blog_id IN (SELECT id FROM blogs WHERE uploaded_by = %s)', (session['user_id'],))
    likes_received = cursor.fetchone()['count']
    
    stats = {
        'blogs': blogs_count,
        'comments': comments_count,
        'likes_received': likes_received
    }
    
    # Get user's blogs
    cursor.execute('''
        SELECT b.*, 
               (SELECT COUNT(*) FROM blog_likes WHERE blog_id = b.id) as likes_count
        FROM blogs b 
        WHERE b.uploaded_by = %s OR b.submitted_by = %s
        ORDER BY b.created_at DESC
    ''', (session['user_id'], session['user_id']))
    user_blogs = cursor.fetchall()
    
    # Get bookmarks
    cursor.execute('''
        SELECT b.*, u.name as author_name
        FROM bookmarks bm
        JOIN blogs b ON bm.blog_id = b.id
        JOIN users u ON b.uploaded_by = u.id
        WHERE bm.user_id = %s
        ORDER BY bm.created_at DESC
    ''', (session['user_id'],))
    bookmarks = cursor.fetchall()
    
    # Get recent activity
    activities = []
    
    # Recent comments
    cursor.execute('''
        SELECT c.*, b.title as blog_title
        FROM comments c
        JOIN blogs b ON c.blog_id = b.id
        WHERE c.user_id = %s
        ORDER BY c.created_at DESC
        LIMIT 5
    ''', (session['user_id'],))
    for comment in cursor.fetchall():
        activities.append({
            'icon': 'comment',
            'description': f'Commented on "{comment["blog_title"]}"',
            'time': comment['created_at'].strftime('%Y-%m-%d %H:%M')
        })
    
    return render_template('profile.html', 
                          user=user, 
                          stats=stats, 
                          user_blogs=user_blogs,
                          bookmarks=bookmarks,
                          activities=activities)


@app.route('/profile/update', methods=['POST'])
def update_profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    name = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip()
    
    if not name or not email:
        return redirect(url_for('profile'))
    
    cursor = get_cursor()
    try:
        cursor.execute('UPDATE users SET name = %s, email = %s WHERE id = %s',
                       (name, email, session['user_id']))
        get_db().commit()
        session['name'] = name
    except:
        pass
    
    return redirect(url_for('profile'))





@app.route('/admin/testimonials')
def admin_testimonials():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    cursor.execute('''
        SELECT t.*, u.name as user_name
        FROM testimonials t
        JOIN users u ON t.user_id = u.id
        ORDER BY t.created_at DESC
    ''')
    testimonials = cursor.fetchall()
    
    # Get stats
    cursor.execute('SELECT COUNT(*) as count FROM testimonials')
    total_testimonials = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM testimonials WHERE is_approved = 0')
    pending_testimonials = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM testimonials WHERE is_approved = 1')
    approved_testimonials = cursor.fetchone()['count']
    
    return render_template('admin_testimonials.html',
                          testimonials=testimonials,
                          total_testimonials=total_testimonials,
                          pending_testimonials=pending_testimonials,
                          approved_testimonials=approved_testimonials)


@app.route('/admin/testimonials/<int:testimonial_id>/approve', methods=['POST'])
def admin_approve_testimonial(testimonial_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    cursor.execute('UPDATE testimonials SET is_approved = 1 WHERE id = %s', (testimonial_id,))
    get_db().commit()
    return redirect(url_for('admin_testimonials'))


@app.route('/admin/testimonials/<int:testimonial_id>/reject', methods=['POST'])
def admin_reject_testimonial(testimonial_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    cursor.execute('UPDATE testimonials SET is_approved = 0 WHERE id = %s', (testimonial_id,))
    get_db().commit()
    return redirect(url_for('admin_testimonials'))


@app.route('/admin/testimonials/<int:testimonial_id>/delete', methods=['POST'])
def admin_delete_testimonial(testimonial_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    cursor.execute('DELETE FROM testimonials WHERE id = %s', (testimonial_id,))
    get_db().commit()
    return redirect(url_for('admin_testimonials'))


# =====================================================
# NEWSLETTER ROUTES
# =====================================================

@app.route('/subscribe', methods=['POST'])
def subscribe_newsletter():
    email = request.form.get('email', '').strip()
    
    if not email:
        return redirect(url_for('home'))
    
    cursor = get_cursor()
    
    try:
        # Check if email already exists
        cursor.execute('SELECT id, is_active FROM newsletter_subscribers WHERE email = %s', (email,))
        existing = cursor.fetchone()
        
        if existing:
            if existing['is_active']:
                # Already subscribed
                return redirect(url_for('home'))
            else:
                # Resubscribe
                cursor.execute('UPDATE newsletter_subscribers SET is_active = 1, unsubscribed_at = NULL WHERE id = %s', 
                               (existing['id'],))
                get_db().commit()
                return redirect(url_for('home'))
        else:
            # New subscription
            cursor.execute('INSERT INTO newsletter_subscribers (email) VALUES (%s)', (email,))
            get_db().commit()
            return redirect(url_for('home'))
    except Exception as e:
        return redirect(url_for('home'))


@app.route('/admin/newsletter')
def admin_newsletter():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    # Get all subscribers
    cursor.execute('''
        SELECT * FROM newsletter_subscribers 
        ORDER BY subscribed_at DESC
    ''')
    subscribers = cursor.fetchall()
    
    # Get stats
    cursor.execute('SELECT COUNT(*) as count FROM newsletter_subscribers')
    total_subscribers = cursor.fetchone()['count']
    
    cursor.execute('SELECT COUNT(*) as count FROM newsletter_subscribers WHERE is_active = 1')
    active_subscribers = cursor.fetchone()['count']
    
    return render_template('admin_newsletter.html',
                          subscribers=subscribers,
                          total_subscribers=total_subscribers,
                          active_subscribers=active_subscribers)


@app.route('/admin/newsletter/<int:subscriber_id>/delete', methods=['POST'])
def admin_delete_subscriber(subscriber_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    cursor.execute('DELETE FROM newsletter_subscribers WHERE id = %s', (subscriber_id,))
    get_db().commit()
    return redirect(url_for('admin_newsletter'))







# =====================================================
# ADMIN BLOG APPROVAL ROUTES
# =====================================================

@app.route('/admin/blogs/approve/<int:blog_id>', methods=['POST'])
def admin_approve_blog(blog_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    cursor.execute('UPDATE blogs SET is_approved = 1, is_published = 1 WHERE id = %s', (blog_id,))
    get_db().commit()
    return redirect(url_for('admin_blogs'))


@app.route('/admin/blogs/reject/<int:blog_id>', methods=['POST'])
def admin_reject_blog(blog_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cursor = get_cursor()
    cursor.execute('SELECT role FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    if user['role'] != 'admin':
        return redirect(url_for('home'))
    
    rejection_reason = request.form.get('rejection_reason', '')
    cursor.execute('UPDATE blogs SET is_approved = 0, is_published = 0, rejection_reason = %s WHERE id = %s', 
                   (rejection_reason, blog_id))
    get_db().commit()
    return redirect(url_for('admin_blogs'))

if __name__ == '__main__':
    with app.app_context():
        init_db()
    app.run(debug=True)
