import mysql.connector
import os
import random
import shutil

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'blogs4you'
}

UPLOAD_DIR = 'static/uploads'

def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

def get_existing_images_for_category(category):
    """Get list of existing images for a category"""
    category_slug = category.lower().replace(' ', '_')
    images = []
    for i in range(1, 4):
        img_name = f"blog_{category_slug}_{i}.jpg"
        img_path = os.path.join(UPLOAD_DIR, img_name)
        if os.path.exists(img_path):
            images.append(f"uploads/{img_name}")
    return images

def copy_image_for_blog(category, blog_id, img_num):
    """Copy existing category image for a blog"""
    category_slug = category.lower().replace(' ', '_')
    source_img = f"blog_{category_slug}_{((blog_id + img_num) % 3) + 1}.jpg"
    source_path = os.path.join(UPLOAD_DIR, source_img)
    
    if os.path.exists(source_path):
        new_filename = f"blog_{category_slug}_{blog_id}_{img_num}.jpg"
        dest_path = os.path.join(UPLOAD_DIR, new_filename)
        
        try:
            shutil.copy2(source_path, dest_path)
            return f"uploads/{new_filename}"
        except:
            return f"uploads/{source_img}"
    
    return None

def add_images_to_blogs():
    """Add images to all blogs"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    print("Adding images to blogs...")
    print("=" * 60)
    
    # Get all blogs
    cursor.execute("SELECT id, title, category FROM blogs ORDER BY id")
    blogs = cursor.fetchall()
    
    total_blogs = len(blogs)
    images_added = 0
    sections_added = 0
    
    for i, blog in enumerate(blogs, 1):
        blog_id = blog['id']
        category = blog['category']
        
        print(f"\n[{i}/{total_blogs}] Blog {blog_id}: {blog['title'][:40]}...")
        
        # Check if blog already has image sections
        cursor.execute("SELECT COUNT(*) as count FROM blog_sections WHERE blog_id = %s AND section_type = 'image'", (blog_id,))
        existing_images = cursor.fetchone()['count']
        
        if existing_images >= 3:
            print(f"    ℹ Already has {existing_images} images, skipping...")
            continue
        
        # Get current max sort_order
        cursor.execute("SELECT MAX(sort_order) as max_order FROM blog_sections WHERE blog_id = %s", (blog_id,))
        result = cursor.fetchone()
        current_max = result['max_order'] if result['max_order'] else -1
        
        # Add 3 images for this blog
        images_added_to_blog = 0
        
        for img_num in range(1, 4):
            # Copy existing image for this blog
            img_path = copy_image_for_blog(category, blog_id, img_num)
            
            if img_path:
                sort_order = current_max + img_num
                
                # Check if this image section already exists
                cursor.execute("""
                    SELECT id FROM blog_sections 
                    WHERE blog_id = %s AND section_type = 'image' AND image_path = %s
                """, (blog_id, img_path))
                
                if not cursor.fetchone():
                    cursor.execute("""
                        INSERT INTO blog_sections (blog_id, section_type, image_path, sort_order)
                        VALUES (%s, %s, %s, %s)
                    """, (blog_id, 'image', img_path, sort_order))
                    sections_added += 1
                    images_added_to_blog += 1
                    images_added += 1
        
        if images_added_to_blog > 0:
            conn.commit()
            print(f"    ✓ Added {images_added_to_blog} images")
        else:
            print(f"    ℹ No new images needed")
    
    cursor.close()
    conn.close()
    
    print("\n" + "=" * 60)
    print("IMAGE ADDITION COMPLETE!")
    print(f"Total blogs processed: {total_blogs}")
    print(f"Total images added: {images_added}")
    print(f"Total image sections: {sections_added}")
    print("=" * 60)

if __name__ == "__main__":
    add_images_to_blogs()
