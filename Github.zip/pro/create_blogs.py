import mysql.connector
import requests
import os
import time
import random
import re
from bs4 import BeautifulSoup
from datetime import datetime
from urllib.parse import quote_plus

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'blogs4you'
}

# Create uploads directory
UPLOAD_DIR = 'static/uploads'
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Admin user ID (from database - mitrajsinh@blogs4you.com)
ADMIN_ID = 2


# Categories with their blog topics
BLOG_TOPICS = {
    'Business': [
        {'title': 'Digital Marketing Strategies That Drive Results in 2024', 'keywords': 'digital marketing SEO social media'},
        {'title': 'How to Secure Startup Funding from Seed to Series A', 'keywords': 'startup funding venture capital investment'},
        {'title': 'Remote Team Management: Best Practices for Global Teams', 'keywords': 'remote work team management collaboration'},
        {'title': 'E-commerce Trends Reshaping the Retail Landscape', 'keywords': 'ecommerce online shopping retail trends'},
        {'title': 'Building a Sustainable Business Model for Long-term Success', 'keywords': 'sustainable business green company'},
        {'title': 'AI Automation: Transforming Business Operations', 'keywords': 'artificial intelligence business automation'},
        {'title': 'Tax Strategies Every Small Business Owner Should Know', 'keywords': 'small business taxes accounting'},
        {'title': 'Creating a Company Culture That Attracts Top Talent', 'keywords': 'company culture employee engagement'},
        {'title': 'Supply Chain Optimization in a Global Economy', 'keywords': 'supply chain logistics management'},
        {'title': 'Customer Retention Strategies That Actually Work', 'keywords': 'customer retention loyalty programs'},
        {'title': 'Data-Driven Decision Making for Modern Businesses', 'keywords': 'business analytics data intelligence'},
        {'title': 'The Entrepreneur Mindset: Traits of Successful Founders', 'keywords': 'entrepreneurship startup founder'}
    ],
    'Education': [
        {'title': 'Online Learning vs Traditional Education: Finding the Right Path', 'keywords': 'online education e-learning comparison'},
        {'title': 'STEM Education: Preparing Students for Future Careers', 'keywords': 'STEM education science technology engineering math'},
        {'title': 'Early Childhood Development: Building Strong Foundations', 'keywords': 'early childhood education preschool learning'},
        {'title': 'Higher Education Trends Shaping Universities in 2024', 'keywords': 'university education college trends'},
        {'title': 'Lifelong Learning: Staying Relevant in the Digital Age', 'keywords': 'continuous learning professional development'},
        {'title': 'Gamification in Education: Making Learning Engaging', 'keywords': 'educational games gamification learning'},
        {'title': 'Inclusive Education: Supporting Students with Special Needs', 'keywords': 'special education inclusive classroom'},
        {'title': 'Vocational Training: The Value of Skilled Trades', 'keywords': 'vocational education technical training'},
        {'title': 'Language Learning: Effective Methods for Fluency', 'keywords': 'language learning bilingual education'},
        {'title': 'Educational Technology Tools Transforming Classrooms', 'keywords': 'edtech classroom technology teaching tools'},
        {'title': 'Study Abroad: International Education Opportunities', 'keywords': 'study abroad international students exchange'},
        {'title': 'Adult Education: Career Transitions and Skill Building', 'keywords': 'adult learning career change education'}
    ],
    'Entertainment': [
        {'title': 'The Streaming Wars: Who Will Dominate Entertainment?', 'keywords': 'streaming services Netflix Disney entertainment'},
        {'title': 'Video Game Industry: From Pixels to Billion Dollar Empire', 'keywords': 'video games gaming industry esports'},
        {'title': 'Music Industry Evolution in the Digital Era', 'keywords': 'music industry streaming Spotify artists'},
        {'title': 'Film Production Technology: CGI and Beyond', 'keywords': 'film production visual effects cinema technology'},
        {'title': 'Content Creation: Building a Career on Social Media', 'keywords': 'social media content creator influencer'},
        {'title': 'Podcasting: From Hobby to Profitable Business', 'keywords': 'podcasting audio content media business'},
        {'title': 'Live Events: The Return of Concerts and Festivals', 'keywords': 'live concerts music festivals events'},
        {'title': 'Animation Industry: Art Meets Technology', 'keywords': 'animation Pixar Disney visual effects'},
        {'title': 'Reality TV Impact on Modern Society', 'keywords': 'reality television social impact media'},
        {'title': 'Celebrity Brand Partnerships and Influencer Marketing', 'keywords': 'celebrity endorsements brand partnerships'},
        {'title': 'Esports: Competitive Gaming as Professional Sport', 'keywords': 'esports competitive gaming tournaments'},
        {'title': 'Theater and Performing Arts in the Modern Era', 'keywords': 'theater performing arts Broadway stage'}
    ],
    'Food': [
        {'title': 'Plant-Based Diet: Health Benefits and Getting Started', 'keywords': 'plant based diet vegan vegetarian health'},
        {'title': 'Mediterranean Cuisine: A Journey Through Flavors', 'keywords': 'Mediterranean diet Greek Italian food'},
        {'title': 'Food Photography: Capturing Culinary Art', 'keywords': 'food photography styling culinary art'},
        {'title': 'Sustainable Farming: From Farm to Table', 'keywords': 'sustainable agriculture organic farming local food'},
        {'title': 'Global Street Food Culture and Its Influence', 'keywords': 'street food international cuisine food trucks'},
        {'title': 'Meal Prep for Busy Professionals: Save Time, Eat Better', 'keywords': 'meal prep healthy eating busy lifestyle'},
        {'title': 'Wine and Food Pairing: A Beginner Guide', 'keywords': 'wine pairing culinary dining gastronomy'},
        {'title': 'The Science of Baking: Perfecting Your Techniques', 'keywords': 'baking techniques pastry bread making'},
        {'title': 'Fermentation: Ancient Techniques for Modern Health', 'keywords': 'fermented foods probiotics gut health'},
        {'title': 'Zero-Waste Cooking: Sustainable Kitchen Practices', 'keywords': 'zero waste cooking sustainable kitchen food waste'},
        {'title': 'Fusion Cuisine: Where Culinary Traditions Meet', 'keywords': 'fusion food culinary innovation global cuisine'},
        {'title': 'Food Safety: Storage, Handling, and Best Practices', 'keywords': 'food safety kitchen hygiene storage'}
    ],
    'Health': [
        {'title': 'Mental Health Awareness: Breaking the Stigma in 2024', 'keywords': 'mental health wellness depression anxiety'},
        {'title': 'Fitness Trends: Home Workouts and Digital Training', 'keywords': 'fitness trends home workout exercise'},
        {'title': 'Nutrition for Immunity: Foods That Boost Your Defenses', 'keywords': 'immune system nutrition healthy foods vitamins'},
        {'title': 'Sleep Science: Optimizing Your Rest for Better Health', 'keywords': 'sleep health insomnia rest optimization'},
        {'title': 'Preventive Healthcare: Screenings and Early Detection', 'keywords': 'preventive health medical screenings wellness'},
        {'title': 'Stress Management: Techniques for Modern Life', 'keywords': 'stress relief mindfulness meditation wellness'},
        {'title': 'Holistic Wellness: Integrating Mind, Body, and Spirit', 'keywords': 'holistic health alternative medicine wellness'},
        {'title': 'Medical Technology: Innovations Changing Healthcare', 'keywords': 'medical technology healthcare innovation telemedicine'},
        {'title': 'Healthy Aging: Strategies for Longevity and Vitality', 'keywords': 'healthy aging longevity anti-aging wellness'},
        {'title': 'Women Health: Important Topics Every Woman Should Know', 'keywords': 'women health gynecology wellness female'},
        {'title': 'Men Health: Fitness, Nutrition, and Wellness Guide', 'keywords': 'men health fitness nutrition male wellness'},
        {'title': 'Pediatric Health: Keeping Children Healthy and Happy', 'keywords': 'children health pediatric care kids wellness'}
    ],
    'Lifestyle': [
        {'title': 'Minimalist Living: Less Stuff, More Life', 'keywords': 'minimalism simple living decluttering lifestyle'},
        {'title': 'Sustainable Fashion: Ethical Choices for Your Wardrobe', 'keywords': 'sustainable fashion ethical clothing eco fashion'},
        {'title': 'Home Organization Systems That Actually Work', 'keywords': 'home organization decluttering storage solutions'},
        {'title': 'Travel Hacking: Explore the World on Any Budget', 'keywords': 'budget travel travel tips cheap flights'},
        {'title': 'Personal Finance: Building Wealth at Any Age', 'keywords': 'personal finance money management investing'},
        {'title': 'Work-Life Balance: Finding Harmony in a Busy World', 'keywords': 'work life balance stress management career'},
        {'title': 'DIY Home Improvement: Projects for Every Skill Level', 'keywords': 'DIY home renovation improvement projects'},
        {'title': 'Gardening for Beginners: Growing Your Green Thumb', 'keywords': 'gardening plants vegetables home garden'},
        {'title': 'Pet Care Guide: Keeping Your Furry Friends Healthy', 'keywords': 'pet care dogs cats animal health'},
        {'title': 'Digital Age Etiquette: Navigating Social Interactions', 'keywords': 'social etiquette digital manners online behavior'},
        {'title': 'Discovering New Hobbies: Enriching Your Free Time', 'keywords': 'hobbies leisure activities creative pursuits'},
        {'title': 'Seasonal Living: Embracing Nature Year-Round', 'keywords': 'seasonal living mindfulness nature connection'}
    ],
    'Science': [
        {'title': 'Climate Change Solutions: Technology and Action', 'keywords': 'climate change global warming solutions'},
        {'title': 'Space Exploration: Latest Discoveries and Missions', 'keywords': 'space exploration NASA Mars astronomy'},
        {'title': 'CRISPR Technology: The Future of Gene Editing', 'keywords': 'CRISPR gene editing biotechnology genetics'},
        {'title': 'Renewable Energy: Solar, Wind, and Beyond', 'keywords': 'renewable energy solar power wind energy green'},
        {'title': 'Ocean Conservation: Protecting Our Marine Ecosystems', 'keywords': 'ocean conservation marine life sea protection'},
        {'title': 'AI Ethics: Navigating the Moral Landscape', 'keywords': 'artificial intelligence ethics technology morality'},
        {'title': 'Quantum Computing: Explaining the Next Revolution', 'keywords': 'quantum computing technology future computing'},
        {'title': 'Biodiversity: Why Every Species Matters', 'keywords': 'biodiversity ecosystems wildlife conservation nature'},
        {'title': 'Neuroscience Discoveries: Understanding the Brain', 'keywords': 'neuroscience brain research cognitive science'},
        {'title': 'Materials Science: Innovations Shaping Our World', 'keywords': 'materials science nanotechnology innovation'},
        {'title': 'Weather Patterns: Understanding Climate Shifts', 'keywords': 'weather climate meteorology patterns'},
        {'title': 'Citizen Science: How You Can Contribute to Research', 'keywords': 'citizen science volunteer research community'}
    ],
    'Sports': [
        {'title': 'Olympic Games: History, Evolution, and Future', 'keywords': 'Olympics sports games athletics competition'},
        {'title': 'Women in Sports: Breaking Barriers and Records', 'keywords': 'women sports female athletes equality'},
        {'title': 'Sports Psychology: The Mental Game of Champions', 'keywords': 'sports psychology mental performance athletes'},
        {'title': 'Athlete Nutrition: Fueling Performance Excellence', 'keywords': 'sports nutrition athlete diet performance'},
        {'title': 'Injury Prevention and Recovery for Athletes', 'keywords': 'sports injury prevention recovery physical therapy'},
        {'title': 'Extreme Sports: Pushing Human Limits', 'keywords': 'extreme sports adventure adrenaline activities'},
        {'title': 'Youth Sports Development: Building Future Champions', 'keywords': 'youth sports kids athletics development coaching'},
        {'title': 'Sports Analytics: Data-Driven Performance', 'keywords': 'sports analytics data statistics performance'},
        {'title': 'Paralympic Movement: Adaptive Sports Excellence', 'keywords': 'Paralympics adaptive sports disability athletics'},
        {'title': 'Esports Recognition: Competitive Gaming as Sport', 'keywords': 'esports professional gaming competitive sport'},
        {'title': 'Outdoor Recreation: Trends in Adventure Sports', 'keywords': 'outdoor sports recreation hiking cycling adventure'},
        {'title': 'Sports Business: Management and Economics', 'keywords': 'sports business management economics industry'}
    ],
    'Technology': [
        {'title': '5G Networks: Transforming Connectivity and Industry', 'keywords': '5G technology mobile networks connectivity'},
        {'title': 'Cybersecurity Essentials: Protecting Your Digital Life', 'keywords': 'cybersecurity online safety privacy protection'},
        {'title': 'Cloud Computing Evolution: From Storage to AI', 'keywords': 'cloud computing AWS Azure Google Cloud'},
        {'title': 'Internet of Things: Smart Devices Everywhere', 'keywords': 'IoT smart home connected devices technology'},
        {'title': 'Blockchain Beyond Crypto: Real-World Applications', 'keywords': 'blockchain technology cryptocurrency applications'},
        {'title': 'Augmented Reality: Changing How We See the World', 'keywords': 'augmented reality AR VR virtual technology'},
        {'title': 'Machine Learning Basics: Understanding AI Systems', 'keywords': 'machine learning AI artificial intelligence data'},
        {'title': 'Smart Home Technology: Living in the Future', 'keywords': 'smart home automation IoT devices connected'},
        {'title': 'Electric Vehicles: The Road to Sustainable Transport', 'keywords': 'electric cars EV Tesla sustainable transport'},
        {'title': 'Tech Startup Ecosystem: Innovation and Investment', 'keywords': 'tech startups Silicon Valley innovation venture'},
        {'title': 'Digital Privacy: Rights and Protections in 2024', 'keywords': 'digital privacy data protection GDPR rights'},
        {'title': 'Future of Work: Technology Transforming Careers', 'keywords': 'future work remote technology automation jobs'}
    ],
    'Travel': [
        {'title': 'Solo Travel Guide: Safety and Adventure Tips', 'keywords': 'solo travel backpacking safety adventure'},
        {'title': 'Budget Travel Hacking: See the World for Less', 'keywords': 'budget travel cheap flights hostels savings'},
        {'title': 'Cultural Immersion: Authentic Travel Experiences', 'keywords': 'cultural travel local experiences authentic tourism'},
        {'title': 'Adventure Travel: Destinations for Thrill Seekers', 'keywords': 'adventure travel extreme destinations hiking'},
        {'title': 'Sustainable Tourism: Traveling Responsibly', 'keywords': 'sustainable tourism eco travel responsible tourism'},
        {'title': 'Digital Nomad Life: Working While Exploring', 'keywords': 'digital nomad remote work travel lifestyle'},
        {'title': 'Cruise Travel: Navigating the Seas in Style', 'keywords': 'cruise travel ocean vacation ship tourism'},
        {'title': 'Road Trip Planning: The Ultimate Guide', 'keywords': 'road trip driving travel route planning'},
        {'title': 'Luxury Travel: Experiences Worth Splurging On', 'keywords': 'luxury travel premium experiences exclusive'},
        {'title': 'Hidden Gems: Underrated Destinations to Visit', 'keywords': 'hidden gems offbeat travel secret destinations'},
        {'title': 'Travel Photography: Capturing Your Journey', 'keywords': 'travel photography camera tips vacation photos'},
        {'title': 'Post-Pandemic Travel: New Normals and Tips', 'keywords': 'post pandemic travel tourism recovery safety'}
    ]
}

def get_db_connection():
    """Create and return database connection"""
    return mysql.connector.connect(**DB_CONFIG)

def download_image(keywords, filename, index=0):
    """Download image from Unsplash or Pexels"""
    try:
        # Try Unsplash Source API first (free, no key required for basic usage)
        unsplash_url = f"https://source.unsplash.com/800x600/?{quote_plus(keywords)}&sig={random.randint(1, 10000)}"
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        response = requests.get(unsplash_url, headers=headers, timeout=15, allow_redirects=True)
        
        if response.status_code == 200 and len(response.content) > 1000:
            filepath = os.path.join(UPLOAD_DIR, filename)
            with open(filepath, 'wb') as f:
                f.write(response.content)
            return f"uploads/{filename}"
        
        # Fallback: Try Pexels API (requires key, but we'll use a placeholder approach)
        # For now, copy existing images as fallback
        return None
        
    except Exception as e:
        print(f"Error downloading image: {e}")
        return None

def scrape_content(topic, category):
    """Generate detailed blog content with human tone"""
    
    # Create comprehensive, human-toned content based on topic
    title = topic['title']
    keywords = topic['keywords']
    
    # Generate introduction
    intro = f"""Welcome to this comprehensive guide on {title.split(':')[0] if ':' in title else title}. Whether you're just starting out or looking to deepen your understanding, this article will walk you through everything you need to know with practical insights and real-world examples.

In today rapidly evolving world, staying informed about {category.lower()} trends isn't just helpful—it's essential. From industry experts to everyday enthusiasts, people are constantly seeking reliable information that can help them make better decisions and stay ahead of the curve."""

    # Generate main content sections
    sections = []
    
    # Section 1: Understanding the Basics
    section1_title = f"Understanding {title.split(':')[0] if ':' in title else title}"
    section1_content = f"""Let start with the fundamentals. {title.split(':')[0] if ':' in title else title} has become increasingly important in our modern landscape. Many people find themselves overwhelmed by the amount of information available, but breaking it down into manageable pieces makes it much more approachable.

The key concepts you need to grasp include the core principles that drive this field forward. Industry leaders have spent years refining these ideas, and today we're seeing them applied in innovative ways across various sectors. What once seemed like niche knowledge has now become mainstream, affecting how we live, work, and interact with the world around us.

Consider how this impacts your daily life. Whether you realize it or not, {category.lower()} plays a significant role in shaping your experiences. From the moment you wake up until you rest, elements of what we discussing here influence your choices and opportunities."""

    sections.append(('text', section1_content))
    
    # Add first image
    img1_filename = f"blog_{category.lower().replace(' ', '_')}_{random.randint(1000, 9999)}_1.jpg"
    img1_path = download_image(topic['keywords'], img1_filename, 1)
    if img1_path:
        sections.append(('image', img1_path))
    
    # Section 2: Deep Dive
    section2_content = f"""Now that we've covered the basics, let explore the deeper aspects. Experts in the field agree that continuous learning is crucial. The landscape is constantly shifting, with new developments emerging regularly. Staying current requires dedication, but the rewards are substantial.

One aspect that often gets overlooked is the human element. Behind every trend and technology, there are people making decisions, solving problems, and pushing boundaries. Their stories provide valuable context and inspiration. When you understand the challenges they've overcome, you gain perspective on your own journey.

Practical application is where theory meets reality. It one thing to understand concepts intellectually, but implementing them successfully requires a different set of skills. Start small, experiment often, and don't be afraid to make mistakes. Each setback is an opportunity to learn and refine your approach."""

    sections.append(('text', section2_content))
    
    # Add second image
    img2_filename = f"blog_{category.lower().replace(' ', '_')}_{random.randint(1000, 9999)}_2.jpg"
    img2_path = download_image(topic['keywords'] + " detail", img2_filename, 2)
    if img2_path:
        sections.append(('image', img2_path))
    
    # Section 3: Practical Applications
    section3_content = f"""Let talk about putting this knowledge into action. The practical applications are vast and varied. Depending on your specific situation, you might approach this differently than someone else. That flexibility is actually one of the strengths of this field.

Start by assessing your current position. What resources do you have available? What constraints are you working within? Understanding your starting point helps you chart the most effective course forward. There no one-size-fits-all solution, but there are proven frameworks that can guide your decisions.

Implementation requires patience and persistence. You won't see results overnight, and that perfectly normal. Focus on building sustainable habits and systems that support your long-term goals. Small, consistent actions compound over time into significant achievements."""

    sections.append(('text', section3_content))
    
    # Add third image
    img3_filename = f"blog_{category.lower().replace(' ', '_')}_{random.randint(1000, 9999)}_3.jpg"
    img3_path = download_image(topic['keywords'] + " example", img3_filename, 3)
    if img3_path:
        sections.append(('image', img3_path))
    
    # Section 4: Future Trends and Conclusion
    section4_content = f"""Looking ahead, the future appears promising. Emerging trends suggest we're on the cusp of significant developments that will reshape how we think about {category.lower()}. Early adopters are already experimenting with new approaches, and their successes point toward exciting possibilities.

However, challenges remain. Not every innovation succeeds, and there will be obstacles along the way. The key is maintaining a balanced perspective—optimistic enough to embrace change, but realistic about the difficulties involved. Surround yourself with supportive communities and stay connected to others who share your interests.

In conclusion, {title.split(':')[0] if ':' in title else title} offers tremendous potential for those willing to engage with it thoughtfully. The journey of discovery is ongoing, and there's always more to learn. We hope this guide has provided you with valuable insights and practical strategies you can apply immediately.

Remember, the most important step is the next one. Take what you've learned here and start implementing it in your own life. Share your experiences with others, ask questions when you need help, and keep pushing forward. The path to mastery is paved with curiosity, persistence, and a willingness to grow."""

    sections.append(('text', section4_content))
    
    # Combine all text for the main content field
    full_content = intro + "\n\n" + section1_content + "\n\n" + section2_content + "\n\n" + section3_content + "\n\n" + section4_content
    
    return {
        'title': title,
        'content': full_content,
        'sections': sections,
        'category': category,
        'keywords': keywords
    }

def create_blog_in_database(blog_data, admin_id):
    """Insert blog into database with sections"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get main image from sections if available
        main_image = None
        for section in blog_data['sections']:
            if section[0] == 'image':
                main_image = section[1]
                break
        
        # If no image downloaded, use existing placeholder
        if not main_image:
            category_slug = blog_data['category'].lower().replace(' ', '_')
            main_image = f"uploads/blog_{category_slug}_{random.randint(1, 3)}.jpg"
        
        # Insert blog
        cursor.execute("""
            INSERT INTO blogs (title, content, category, image, uploaded_by, 
                           submitted_by, is_published, is_approved, views)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            blog_data['title'],
            blog_data['content'],
            blog_data['category'],
            main_image,
            admin_id,
            admin_id,
            1,  # is_published
            1,  # is_approved
            random.randint(50, 500)  # initial views
        ))
        
        blog_id = cursor.lastrowid
        
        # Insert sections
        for i, (section_type, content) in enumerate(blog_data['sections']):
            if section_type == 'text':
                cursor.execute("""
                    INSERT INTO blog_sections (blog_id, section_type, content, sort_order)
                    VALUES (%s, %s, %s, %s)
                """, (blog_id, 'text', content, i))
            elif section_type == 'image':
                cursor.execute("""
                    INSERT INTO blog_sections (blog_id, section_type, image_path, sort_order)
                    VALUES (%s, %s, %s, %s)
                """, (blog_id, 'image', content, i))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return blog_id
        
    except Exception as e:
        print(f"Error creating blog: {e}")
        return None

def main():
    """Main function to create all 120 blogs"""
    print("Starting blog creation process...")
    print("=" * 60)
    
    total_blogs = 0
    successful_blogs = 0
    
    for category, topics in BLOG_TOPICS.items():
        print(f"\nProcessing category: {category}")
        print("-" * 40)
        
        for i, topic in enumerate(topics, 1):
            total_blogs += 1
            print(f"  Creating blog {i}/12: {topic['title'][:50]}...")
            
            # Generate blog content
            blog_data = scrape_content(topic, category)
            
            # Create in database
            blog_id = create_blog_in_database(blog_data, ADMIN_ID)
            
            if blog_id:
                successful_blogs += 1
                print(f"    ✓ Created blog ID: {blog_id}")
            else:
                print(f"    ✗ Failed to create blog")
            
            # Small delay to be respectful to image services
            time.sleep(0.5)
        
        print(f"  Completed {category}: {successful_blogs} total blogs created")
    
    print("\n" + "=" * 60)
    print(f"BLOG CREATION COMPLETE!")
    print(f"Total blogs attempted: {total_blogs}")
    print(f"Successfully created: {successful_blogs}")
    print(f"Success rate: {(successful_blogs/total_blogs)*100:.1f}%")
    print("=" * 60)

if __name__ == "__main__":
    main()
